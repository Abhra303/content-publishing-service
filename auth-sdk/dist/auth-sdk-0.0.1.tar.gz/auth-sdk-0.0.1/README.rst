This python package is for internal use only. This app is responsible
for communication between different micro-services and User micro-services.

